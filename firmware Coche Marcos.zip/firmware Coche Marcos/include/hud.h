#pragma once
namespace HUD {
    void init();
    void showLogo();
    void showReady();
    void showError();
    void update();
}