#pragma once
#include "pins.h"

// Configuración para ESP32-S3 DevKitC-1 + pantalla 480x320 (ILI9488) + táctil XPT2046
// Orientación horizontal, bus SPI compartido

// ---------- Controlador ----------
#define ILI9488_DRIVER

// ---------- Dimensiones ----------
#define TFT_WIDTH  480
#define TFT_HEIGHT 320

// ---------- Pines TFT (SPI) ----------
#define TFT_MOSI  PIN_TFT_MOSI
#define TFT_MISO  PIN_TFT_MISO
#define TFT_SCLK  PIN_TFT_SCK
#define TFT_CS    PIN_TFT_CS
#define TFT_DC    PIN_TFT_DC
#define TFT_RST   PIN_TFT_RST

// ---------- Pines táctil XPT2046 ----------
#define TOUCH_CS   PIN_TOUCH_CS
#define TOUCH_IRQ  PIN_TOUCH_IRQ   // opcional

// ---------- Rotación ----------
#define TFT_ROTATION 1   // 0..3 (1 = horizontal con parte larga abajo)

// ---------- Frecuencias SPI ----------
#define SPI_FREQUENCY       40000000
#define SPI_READ_FREQUENCY  20000000

// ---------- Opciones avanzadas ----------
// #define TFT_SPI_OVERLAP   // No usar en ESP32-S3 salvo que compartas con flash